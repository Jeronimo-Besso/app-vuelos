import customtkinter as ctk
import sqlite3
from CTkMessagebox import CTkMessagebox
from datetime import datetime

class DashboardSeccion:
    def __init__(self, parent):
        self.parent = parent
        self.conn_finanzas = sqlite3.connect('finanzas.db')
        self.cursor_finanzas = self.conn_finanzas.cursor()
        self.conn_tramos = sqlite3.connect('tramos.db')
        self.cursor_tramos = self.conn_tramos.cursor()
        self.conn_historial = sqlite3.connect('historial.db')
        self.cursor_historial = self.conn_historial.cursor()
        self.setup_database()
        self.porcentaje_comision = self.cargar_porcentaje_comision()
        self.frame_principal = None

    def setup_database(self):
        self.cursor_finanzas.execute('''CREATE TABLE IF NOT EXISTS tramos_finanzas
                                     (id INTEGER PRIMARY KEY, vuelo TEXT, precio REAL, id_cliente INTEGER,
                                      estado TEXT, pagado INTEGER)''')
        self.cursor_finanzas.execute('''CREATE TABLE IF NOT EXISTS config_comision
                                     (id INTEGER PRIMARY KEY,
                                      porcentaje_comision REAL NOT NULL,
                                      fecha_actualizacion TEXT NOT NULL)''')
        self.conn_finanzas.commit()

    def cargar_porcentaje_comision(self):
        try:
            self.cursor_finanzas.execute("SELECT porcentaje_comision FROM config_comision ORDER BY fecha_actualizacion DESC LIMIT 1")
            resultado = self.cursor_finanzas.fetchone()
            return resultado[0] if resultado else 7.0
        except:
            return 7.0

    def guardar_porcentaje_comision(self, porcentaje):
        self.cursor_finanzas.execute("INSERT INTO config_comision (porcentaje_comision, fecha_actualizacion) VALUES (?, ?)",
                                   (porcentaje, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        self.conn_finanzas.commit()

    def sincronizar_tramos(self):
        # Obtener tramos de tramos.db
        self.cursor_tramos.execute("SELECT id, vuelo, precio, id_cliente, estado, pagado FROM tramos")
        tramos = self.cursor_tramos.fetchall()

        # Obtener tramos de historial.db
        self.cursor_historial.execute("SELECT id, vuelo, precio, id_cliente, 'Finalizado', pagado FROM historial_vuelos")
        historial = self.cursor_historial.fetchall()

        # Combinar tramos activos y finalizados
        todos_tramos = tramos + historial

        # Insertar en finanzas.db, ignorando duplicados
        for tramo in todos_tramos:
            self.cursor_finanzas.execute('''INSERT OR IGNORE INTO tramos_finanzas
                                         (id, vuelo, precio, id_cliente, estado, pagado)
                                         VALUES (?, ?, ?, ?, ?, ?)''', tramo)

        self.conn_finanzas.commit()

    def calcular_vuelos_activos(self):
        try:
            self.cursor_tramos.execute("SELECT COUNT(*) FROM tramos WHERE estado='Activo'")
            return self.cursor_tramos.fetchone()[0]
        except:
            return 0

    def calcular_ventas_brutas(self):
        try:
            self.cursor_finanzas.execute("SELECT SUM(precio) FROM tramos_finanzas")
            total = self.cursor_finanzas.fetchone()[0]
            return total if total is not None else 0.0
        except:
            return 0.0

    def calcular_comision(self):
        try:
            total = self.calcular_ventas_brutas()
            comision = total * (self.porcentaje_comision / 100)
            return comision
        except:
            return 0.0

    def calcular_vuelos_no_pagados(self):
        try:
            self.cursor_finanzas.execute("SELECT COUNT(*) FROM tramos WHERE pagado=0")
            return self.cursor_finanzas.fetchone()[0]
        except:
            return 0

    def render(self):
        if self.frame_principal is not None:
            self.frame_principal.destroy()

        self.sincronizar_tramos()

        self.frame_principal = ctk.CTkFrame(self.parent, fg_color="white")
        self.frame_principal.pack(fill="x", padx=20, pady=20)
        self.frame_principal.columnconfigure((0, 1, 2, 3), weight=1)

        ctk.CTkLabel(self.frame_principal, text="Dashboard", text_color="#8BC34A", 
                     font=("Arial", 60, "bold")).grid(row=0, column=0, columnspan=4, padx=40, pady=20)

        self.crear_tarjeta(self.frame_principal, "       Vuelos Activos       ", self.calcular_vuelos_activos, 1, 1)
        self.crear_tarjeta(self.frame_principal, "        Ventas Brutas       ", lambda: f"${self.calcular_ventas_brutas():.2f}", 2, 1)
        self.crear_tarjeta(self.frame_principal, "       Comisión Total       ", lambda: f"${self.calcular_comision():.2f}", 1, 2)
        self.crear_tarjeta(self.frame_principal, "       Vuelos A Cobrar       ", self.calcular_vuelos_no_pagados, 2, 2)

        frame_comision = ctk.CTkFrame(self.frame_principal, fg_color="#8BC34A")
        frame_comision.grid(row=6, column=0, columnspan=3, pady=20, padx=20)
        ctk.CTkLabel(frame_comision, text="Porcentaje de Comisión (%):", text_color="white").pack(side="left", padx=10)
        self.entry_comision = ctk.CTkEntry(frame_comision, width=100)
        self.entry_comision.insert(0, str(self.porcentaje_comision))
        self.entry_comision.pack(side="left", padx=10)
        ctk.CTkButton(frame_comision, text="Actualizar", fg_color="#8BC34A", text_color="white", width=100,
                      command=self.actualizar_comision).pack(side="left", padx=10)

    def crear_tarjeta(self, parent, titulo, calculo_func, fila, columna):
        frame = ctk.CTkFrame(parent, fg_color="#8BC34A", width=400, height=400)
        frame.grid(row=fila, column=columna, padx=30, pady=50)
        ctk.CTkLabel(frame, text=titulo.upper(), font=("Arial", 14, "bold"), text_color="white").pack(pady=5)
        try:
            valor = calculo_func()
        except:
            valor = "0" if "Vuelos" in titulo else "$0.00"
        label_valor = ctk.CTkLabel(frame, text=str(valor), font=("Arial", 12), text_color="white")
        label_valor.pack()
        return label_valor

    def actualizar_comision(self):
        try:
            nuevo_porcentaje = float(self.entry_comision.get())
            if 0 <= nuevo_porcentaje <= 100:
                self.porcentaje_comision = nuevo_porcentaje
                self.guardar_porcentaje_comision(nuevo_porcentaje)
                self.render()
            else:
                CTkMessagebox(title="Error", message="El porcentaje debe estar entre 0 y 100.", icon="warning")
        except ValueError:
            CTkMessagebox(title="Error", message="Por favor, ingrese un número válido.", icon="warning")

    def __del__(self):
        self.conn_finanzas.close()
        self.conn_tramos.close()
        self.conn_historial.close()