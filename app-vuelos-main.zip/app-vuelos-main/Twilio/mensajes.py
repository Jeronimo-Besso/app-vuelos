from datetime import timedelta
import sqlite3
from datetime import datetime
from twilio.rest import client
def enviar_mensaje_tramo_proximo(self):
    try:
        ahora = datetime.now()
        self.cursor.execute("""
            SELECT id, vuelo, fecha_salida, hora_salida, pasajero, id_cliente, codigo_reserva, aeropuerto_salida, aeropuerto_llegada, aerolinea 
            FROM tramos 
            WHERE estado='Activo' AND fecha_salida BETWEEN ? AND ?
        """, (ahora, ahora + timedelta(hours=24))) #busca tramos q salgan en 24h
        tramos_proximos = self.cursor.fetchall()

        for tramo in tramos_proximos:
            tramo_id, vuelo, fecha_salida, hora_salida, pasajero, id_cliente, codigo_reserva, aeropuerto_salida, aeropuerto_llegada, aerolinea = tramo
            conn_clientes = sqlite3.connect('clientes.db')
            cursor_clientes = conn_clientes.cursor()
            cursor_clientes.execute("SELECT nombre, telefono FROM clientes WHERE id=?", (id_cliente,))
            cliente = cursor_clientes.fetchone() #busca cliente
            if cliente:
                nombre, telefono_cliente = cliente
                fecha = fecha_salida.strftime('%d/%m/%Y') #toma fecha
                mensaje = f"""
                Hola {nombre},

                Te recordamos que tu vuelo es mañana:

                Aerolínea: {aerolinea}
                Vuelo: {vuelo}
                Fecha: {fecha}
                Código de reserva: {codigo_reserva}
                Hora de salida: {hora_salida}
                Desde: {aeropuerto_salida}

                - No olvides llevar tu documentación original y vigente (DNI, pasaporte y/o visa según el destino).
                - Se recomienda llegar al aeropuerto con al menos 3 horas de anticipación si es un vuelo internacional, o 2 horas si es nacional.
                - Importante: esta información puede estar sujeta a cambios por parte de la aerolínea. Recomendamos verificar el estado actualizado del vuelo en su sitio web antes de salir.

                🫶 Que tengas un muy buen viaje,
                Álvaro — Equipo Fernweh
                """
                message = client.messages.create(
                    body=mensaje,
                    from_="54",  # Número de Twilio
                    to=telefono_cliente
                )
                print(f"Mensaje enviado a {telefono_cliente}: {mensaje}")

            conn_clientes.close()

    except Exception as e:
        print(f"Error al enviar mensaje: {str(e)}")
